# Dicoding Collection Dashboard  

## Setup Environment - Google Colab  

```python
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt

# Run steamlit app
streamlit run Python.py
